from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import PhilasearchItem
import re

import csv
import datetime


class PhilasearchSpider(CrawlSpider):

    id = 0

    name = "philasearch"

    date_time = None

    parent = []
    child = []

    main_link = "https://www.philasearch.com/de/dosearch.php?set_sprache=de&set_gesetz_bestaetigt_jn=J&gesetz_bestaetigt_neu=J&treeparent=parent_here%2Cchild_here&ab_datum=yyy-mm-dd"

    only_parent = "https://www.philasearch.com/de/dosearch.php?set_sprache=de&set_gesetz_bestaetigt_jn=J&gesetz_bestaetigt_neu=J&treeparent=parent_here&ab_datum=yyy-mm-dd"

    img_code = ["nogum.png","hinge.png","mint.png","cancel.png","letterpiece.png","letter.png"]

   # start_urls = ["https://www.philasearch.com/de/i_9209_272848/35_Altdeutschland_Hamburg/9209-A196-1628.html?set_sprache=de&treeparent=COSUBGRP-10280%2CCO-35&postype=PH"]

    def __init__(self, new, *args, **kwargs):                    
        super(PhilasearchSpider, self).__init__(*args, **kwargs) 

        self.new = new

        if new == "no":
            id_file = open("id.txt","r")
            self.id = id_file.readline()
            self.id = self.id.strip("\n")

            self.id = int(self.id)
            id_file.close()

        self.date_time = datetime.datetime.now()

        date_file = open("date.txt","r")
        crawl_date = date_file.readline()
        crawl_date = crawl_date.strip("\n")
        date_file.close()

        date_file = open("date.txt","r")
        crawl_date = date_file.readline()
        crawl_date = crawl_date.strip("\n")
        date_file.close()

        today = datetime.date.today()
        next_date = open("date.txt",'w')
        next_date.write(str(today))
        next_date.close()


        self.links = [] 
        self.parents_record = []
        self.child_record = []

        with open('input.csv') as csv_file:
            csv_reader = csv.DictReader(csv_file)

            for row in csv_reader:
                
                parent = row["parent"]

                self.parents_record.append(parent)

                if row["child"]:
                    childs = ([x for x in row["child"].split(",")])
                    self.child_record.append(childs)

                    for child in childs:
                        temp = self.main_link
                        temp = temp.replace("parent_here",str(parent))
                        temp = temp.replace("child_here",str(child))
                        temp = temp.replace("yyy-mm-dd",crawl_date)

                        self.links.append(temp)
                else:
                        temp = self.only_parent
                        temp = temp.replace("parent_here",str(parent))
                        temp = temp.replace("yyy-mm-dd",crawl_date)
                        self.links.append(temp)

    def start_requests(self):   

        for url in self.links:                         
            print(url)            
            yield Request(url = url, callback = self.parsee)  
 
   
    def parsee(self, response):

        product_page_links = response.css(".card-overlay::attr(href)").extract()

        for product_page_link in product_page_links:
            yield response.follow(product_page_link,callback=self.product_page)


        next_page = response.css(".pagination.text-right li:last-child a::attr(href)").extract_first() 
        yield response.follow(next_page,callback=self.parsee)       

    
    def product_page(self,response):

        product = PhilasearchItem()

        for index,parent  in enumerate(self.parents_record):
            if parent in response.url:
                product["parent"] = parent
                
                product["child"] = 'None'

                if len(self.child_record) > index:
                    for child in self.child_record[index]:
                        if child in response.url:
                            product["child"] = child      
                            break            

                break  

        product["crawler_started_at"] = self.date_time

        product["id"] = self.id

        id_file = open("id.txt","w")
        id_file.write(str(self.id))
        id_file.close()

        self.id += 1

        name_no_of_auction = response.css(".flex-child-auto.toolbar-section h4::text").extract()  
        name_no_of_auction = " ".join(name_no_of_auction)     
        name_no_of_auction = name_no_of_auction.strip() 

        try:
            product["Name_of_auction"] = name_no_of_auction.split("-")[0]
            product["number_of_auction"] = name_no_of_auction.split("-")[1]
        except:
            product["Name_of_auction"] = name_no_of_auction
            product["number_of_auction"] = 'None'


        product["date_of_auction"] = response.css(".auction-time.show-for-large::text").extract()        
        product["date_of_auction"] = "".join(product["date_of_auction"])
        product["date_of_auction"] = product["date_of_auction"].strip()
        product["date_of_auction"] = product["date_of_auction"].replace("Auktionstermin: ","")

        product["lot_number"] = response.css(".grid-x h2::text").extract()        
        product["lot_number"] = "".join(product["lot_number"])
        product["lot_number"] = product["lot_number"].strip()
        product["lot_number"] = product["lot_number"].replace("Los ","")


        product["category_lot_sold"] = response.css(".grid-x h2 small::text").extract()        
        product["category_lot_sold"] = "".join(product["category_lot_sold"])
        product["category_lot_sold"] = product["category_lot_sold"].strip()


        product["img_code"] = 'None'
        img_code = response.css("#specification img::attr(src)").extract()
        
        if not img_code:
            product["img_code"] = 'None'
        else:
            product["img_code"] =""
            for index,code in enumerate(self.img_code):

                for code_img in img_code:

                        if code in str(code_img):

                            product["img_code"] = product["img_code"]+str(index)
                            
                            break

        product["catalog_name"] = response.css(".label.secondary.catalog-name::text").extract_first()  
        product["catalog_number"] = response.css(".label.catalog-no::text").extract_first()      

        product["description"] = response.css("#posdetail-detail h5 + p::text").extract_first() 
        product["description"] = product["description"].replace("'","")

        product["estimate_of_item"] = response.css("h3[data-localized-number-type='currency']::text").extract_first()
        product["estimate_of_item"] = product["estimate_of_item"].replace("\xa0"," ")

        product["product_images"] =  response.css('script:contains("var data")::text').extract_first()

        if  product["product_images"] :   
            product["product_images"] =   product["product_images"].split("],")[0]
            product["product_images"] = re.findall(r'(https?://[^\s]+)', product["product_images"])
            product["product_images"] = list(dict.fromkeys(product["product_images"]))

            img_links = []

            for link in product["product_images"]:

                if "_" not in link:
                    link = link.replace('",',"")
                    img_links.append(link)
                    
            product["product_images"] = img_links
        else:
            product["product_images"] = 'None'

        sold = response.css(".sale-price-desc span:last-child::text").extract_first()

        if sold == "Ausruf":
            product["sold"] = '0'
        elif "Zuschlag" in sold:
            product["sold"] = '1'
        else:
            product["sold"] = "None"


        yield product