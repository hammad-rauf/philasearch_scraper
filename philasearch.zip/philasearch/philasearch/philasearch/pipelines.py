# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
import scrapy
import sqlite3

from scrapy.pipelines.images import ImagesPipeline

class PhilasearchImagePipeline(ImagesPipeline):
    def get_media_requests(self, item, info):       
        count = 0
        if not item['product_images'] == 'None':
            for img_url in item['product_images']:
                count += 1
                yield scrapy.Request(img_url, meta={'image_name': item["id"],'count': count})

    def file_path(self, request, response=None, info=None):
        return f"{request.meta['image_name']}'_{request.meta['count']}'.jpg" 

class PhilasearchPipeline(object):

    def __init__(self,new):

        self.create_connection()
        self.create_table(new)
        pass

    @classmethod
    def from_crawler(cls, crawler):
        return cls(new=crawler.spider.new)


    def create_connection(self):

        self.conn = sqlite3.Connection('philasearch.db')
        self.curr = self.conn.cursor()
    
    def create_table(self,new):

        if new == "yes":

            self.curr.execute("drop table if exists philasearch_table")
            self.curr.execute("CREATE TABLE philasearch_table( id text, crawler_started_at text,Name_of_auction text,number_of_auction text, date_of_auction text, lot_number text, category_lot_sold text, img_code text, product_images text,catalog_name text, catalog_number text, description text, estimate_of_item text ,sold text,parent text,child text)")

    def process_item(self, item, spider):

        self.store_db(item)

        return item

    def store_db(self,item):

        product_images = ",".join(item["product_images"])

        self.curr.execute(f"insert into philasearch_table values ('{item['id']}','{item['crawler_started_at']}','{item['Name_of_auction']}','{item['number_of_auction']}','{item['date_of_auction']}','{item['lot_number']}','{item['category_lot_sold']}','{item['img_code']}','{product_images}','{item['catalog_name']}','{item['catalog_number']}','{item['description']}','{item['estimate_of_item']}','{item['sold']}','{item['parent']}','{item['child']}')")

        self.conn.commit()
