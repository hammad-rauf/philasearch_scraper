# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

from scrapy import Item, Field


class PhilasearchItem(Item):

    id = Field()

    crawler_started_at = Field()

    Name_of_auction = Field()
    number_of_auction = Field()

    date_of_auction = Field()
    lot_number = Field()
    category_lot_sold = Field()
    img_code = Field()
    product_images = Field()

    catalog_name = Field()
    catalog_number = Field()

    description = Field()
    estimate_of_item = Field()

    sold = Field()


    parent = Field()
    child = Field()

    pass
